# Contracts to freeze before implementation

This document defines semantics. Phase 1 must turn them into strict versioned JSON Schemas, examples and validation tests before application code relies on them.

## Events

Required envelope fields: `event_schema_version`, `event_id`, `sensor_id`, `sensor_boot_id`, `sequence`, `log_type`, `event_time`, `sensor_emitted_at`, `receiver_received_at`, `capture_mode`, `observation_coverage`, `payload`.

- Schema versions are explicit strings, initially `1.0.0`.
- Timestamps are UTC with documented precision. Preserve original capture time and separate replay wall-clock timestamps. Do not subtract historical PCAP timestamps from current wall time for processing latency.
- `capture_mode`: `pcap_replay`, `synthetic_log`, or reserved `passive_live`.
- `observation_coverage`: `both_directions`, `originator_only`, `responder_only`, or `unknown`. Both directions is the default input expectation, not proof that no capture loss occurred.
- Event IDs derive deterministically from sensor/boot/sequence and original record identity. Persist sender identity and sequence across restart. A new scenario run gets a new replay run ID; restarting the same run preserves its identity.
- Scope Zeek UID with sensor and boot ID. Community ID is optional correlation data, not a universally unique event identifier.
- Retain an original-record hash and bounded original record for forensic correlation, subject to export policy.
- All input is size-limited and validated before expensive parsing. Quarantine incompatible schema versions and invalid values with reasons.

## Availability semantics

Each optional telemetry field has a value and availability state, either represented inline or in a versioned side map:

| State | Meaning |
|---|---|
| AVAILABLE | Valid observed value, including a genuine zero |
| MISSING | Expected for this record/capability, but absent |
| NOT_APPLICABLE | Does not apply, e.g. TLS version for a plain DNS UDP flow |
| UNKNOWN | Cannot determine validity/visibility, including unresolved direction or capture coverage |

Record reason codes when useful. A model may use trained imputation with indicators only if its manifest explicitly permits it. A required unavailable feature causes abstention, not invented evidence.

## Topics and consumers

| Topic | Producer | Independent consumers |
|---|---|---|
| `raw-events.v1` | Receiving-side publisher | `flink-detection-v1`, `raw-clickhouse-v1`, optional archive consumer |
| `features.v1` | Flink | `features-clickhouse-v1`, optional research export |
| `alerts.v1` | Flink incident logic | `alerts-clickhouse-v1`, `alerts-opensearch-v1`, `alerts-notifier-v1`, `alerts-live-api-v1` |
| `invalid-events.v1` | Receiver/Flink | Restricted quarantine persistence |
| `sensor-health.v1` | Receiving publisher from outward health telemetry | Metrics adapter and audit sink |

Default demo candidate: 3 raw partitions, replication factor 1; production-like: 3 brokers and RF3 with tested acknowledgement/minimum-replica behavior. Define all topics explicitly; disable accidental auto-creation where practical. Pin bounded retention and record disk budgets. Do not compact raw event topics. Consumer groups acknowledge offsets only after the required durable write succeeds.

## Features and state

Each feature catalog row must define name, scalar/vector type, unit, source, formula, window, key, availability rule, clipping/normalization, model consumers and explanation meaning.

Initial feature groups:

- Destination/service rates: packets, bytes, new flows, source cardinality, source entropy, protocol mix.
- Source scanning: unique destination hosts/ports, sequentiality, observed success/failure ratio.
- Source/destination/service beaconing: count, robust IAT dispersion, median IAT, persistence, size consistency.
- Source/registrable-domain DNS: length, entropy, digit ratio, n-grams, record types, unique labels, rates, observed NXDOMAIN ratio.
- Encrypted metadata: available TLS fields/fingerprints, visible QUIC header fields, bounded packet size/timing statistics.
- Asset exfiltration: outbound delta bytes, sustained rate, inbound/outbound ratio, baseline deviation and passive destination rarity.

Start with 1-second rate buckets, 5/30-second aggregate horizons and a configurable 5-minute beacon horizon. These are candidate settings, not universal detection guarantees. Slow-scan/exfiltration horizons may be longer but remain bounded. Avoid storing every packet or building unbounded per-IP sets. Specify per-key and total state budgets; use tested sketches where appropriate.

Periodic cumulative flow snapshots must be converted to deltas exactly once. Conn terminal summaries enrich/end the flow; they must not re-add all previous bytes or increment new-flow counts again. Reset/regression in counters is a quality event. Late duplicates cannot move counters backwards.

Event-time windows use an initial 2-second out-of-order allowance and 5-second partition-idleness candidate. Tune from replay measurements. Early alerts fire when sufficient evidence exists; they must not always wait for window closure. Record late-event behavior explicitly, including incident updates. Use event-time timers for semantic expiry and state TTL as additional cleanup, not as a replacement for event-time logic.

## Alerts and incident updates

Required fields: `alert_schema_version`, `alert_id`, `incident_id`, `update_id`, `timestamp`, `event_time`, `flow_id`, source/destination IP/port, protocol, threat class, severity, confidence, `confidence_kind`, model/detector version, feature-schema version, detection method, evidence, top features, window start/end, first/last seen, deduplication key and status.

- Protocol-dependent addresses/ports may be null with explicit semantics. Validate enums and bounds.
- `confidence_kind`: `calibrated_probability`, `heuristic_score`, or `unavailable`. Unknown confidence is null, never a fabricated probability.
- `model_version` is null for rules-only alerts; include `detector_version` always.
- Keep stable incident IDs and deterministic update IDs. A stronger observation updates/escalates an incident without paging once per packet.
- Bounded evidence references immutable raw-event IDs and includes actual observed values, thresholds, baseline context, visibility and model eligibility.
- Store incident updates append-only; expose the latest incident state separately. ClickHouse and OpenSearch must use explicit deduplication/upsert semantics; eventual table merges alone are not immediate deduplication.
- Notifier idempotency uses durable processed update IDs. External webhook exactly-once behavior cannot be guaranteed without recipient cooperation.

## Model bundle

Directory per threat and immutable version: `model.onnx`, `metadata.json`, `feature_schema.json`, checksum file, calibration parameters and training provenance. Only populate ONNX files for actually trained and tested models.

Manifest fields: threat, version, ordered inputs/dtypes/shapes, opset, native/runtime compatibility, preprocessing and feature version, required fields, missingness policy, output semantics, calibration version, dataset references/hashes, split method, evaluation metrics, creation time and checksum.

Use an explicit deployment manifest selecting versions. Startup validates, warms and records health before activation. Recoveries must reuse the selected version. Promotion/rollback changes a version reference and uses a controlled savepoint/redeploy procedure. No automatic downloads or registry calls in the hot path.
