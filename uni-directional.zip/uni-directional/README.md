# Passive OT threat detection — SIH26145

This repository currently contains an implementation handoff and directory scaffold. It does not yet contain a running detector, trained model, or Docker Compose deployment.

Start with [IMPLEMENTATION_PLAN.md](IMPLEMENTATION_PLAN.md). Implementing agents must read [AGENTS.md](AGENTS.md) and [docs/ml-research.md](docs/ml-research.md).

The agreed scope is an offline, restart-resilient simulation of passive OT monitoring. Both directions of observed conversations are available. Analytics must never probe observed addresses, decrypt application payloads, or send commands back to the monitored side.

Primary requirements:

- Java Flink detection with bounded state and local ONNX inference.
- Redpanda ingestion and independent storage/search/notification consumers.
- Zeek processing of local PCAPs, plus a distinct synthetic-log test mode.
- Explainable streaming alerts, ClickHouse persistence, a minimal security dashboard, and Grafana platform health.
- A target of less than 3 seconds from sufficient evidence arriving to a visible alert; a 5-second normal-load deadline to verify on declared hardware.
- Named persistent volumes, automatic recovery, and an air-gap deployment bundle.

No throughput, accuracy, latency, restart, or physical-isolation guarantee has been measured yet. The handoff defines how to prove them.
